#include <stdbool.h>
#include <stdint.h>
#include "Uart.h"
#include "led.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/systick.h"
#include "driverlib.h"
#include "button.h"
#include "Timer.h"
#include  "system_init.h"
#include "driverlib/sysctl.h"
#include "Timer_myself.h"
#include "delay.h"
#include "oled.h"
#include "TIM_PWM.h"
char dis1[20]={"hello"};
int main(void)
{   uint16_t ii=50;
   
  	sys_init();
	  PWM_Int4Channel();	
	//	soft_i2c_init();
    //OLED_Init();
	  capture_init();
    led_init();
	  TIM1_init();
	//  TIM0_init();
    Buttons_Init();
    UARTConfigz();

    led_control(0xf);
    while (1)
    { 
			 //  ii+=50;
			   delay_ms(200);
			   enable_cap();
			   SetPWMBI(5000,10000,20000,40000);
         uint8_t button_status = Buttons_Read();
       // Printf(1,dis1);
     //   Printf(2,"hhhh");
        if (button_status & 0x01)
        {  led_control(0x09);
					
           UARTSend(( uint8_t *)"button1\r\n",9); 
					 delay_ms(100);
        }
        if (button_status & 0x02)
        {
					led_control(0x03);
        
					UARTSend((uint8_t *)"button2\r\n",9);
					delay_ms(100);
        }
  
    }
}
