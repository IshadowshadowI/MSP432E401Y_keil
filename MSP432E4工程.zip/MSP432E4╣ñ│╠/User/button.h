#include "driverlib.h"
#define BUTTON1_PIN GPIO_PIN_0
#define BUTTON2_PIN GPIO_PIN_1

void Buttons_Init(void);
uint8_t Buttons_Read(void);


