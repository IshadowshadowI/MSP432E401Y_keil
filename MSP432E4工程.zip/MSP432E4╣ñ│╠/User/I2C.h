 /*****************************************************************************
 *                MSP432E401Y                      MSP432E401Y
 *             ------------------               ------------------
 *         /|\|      MASTER      |             |      SLAVE       |
 *          | |                  |             |                  |
 *          --|RST            PG0|<->I2C1SCL<->|PG0               |
 *            |               PG1|<->I2C1SDA<->|PG1               |
 *            |                  |             |                  |
 *            |               PN0|-->LED D2    |                  |
 *            |                  |             |                  |
 *            |                  |             |                  |
 * Author: 
 ******************************************************************************/
#include <driverlib.h>
#include <stdbool.h>
#include <stdlib.h>



/* Defines for I2C bus parameters */
#define SLAVE_ADDRESS   0x26
#define I2C_NUM_DATA    4

/* Defines for I2C State Machine */
#define I2C_MASTER_IDLE 0x0
#define I2C_MASTER_TX   0x1
#define I2C_MASTER_RX   0x2
#define I2C_MASTER_ANAK 0x3//Ӧ��
#define I2C_MASTER_DNAK 0x4//��Ӧ��
#define I2C_MASTER_ALST 0x5
#define I2C_MASTER_UNKN 0x6






void I2C1_IRQHandler(void);
void I2Cconfig(void);




