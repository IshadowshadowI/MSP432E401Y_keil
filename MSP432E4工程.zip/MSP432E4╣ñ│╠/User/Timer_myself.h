#include "led.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/systick.h"
#include "driverlib.h"
#include "Timer.h"
#include  "system_init.h"
#include "driverlib/sysctl.h"


void Timer0AIntHandler(void);
//void TIM0_init(void);
void Timer1AIntHandler(void);
void TIM1_init(void);
void TIMER3B_IRQHandler(void);
void capture_init(void);
void enable_cap(void);//Call this function in a loop in while(1).


