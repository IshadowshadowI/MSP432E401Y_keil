#include "led.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/systick.h"
#include "driverlib.h"
#include "Timer.h"
#include  "system_init.h"
#include "driverlib/sysctl.h"
#include "stdio.h"
#include "Uart.h"
#include "delay.h"
volatile uint16_t getTimerCaptureValue;
volatile bool bSetEventFlag;

uint32_t num[4];
long Circle_high,Circle_low,total;
float duty;
int frequency;
int flag;
char output1[20]={'0'};
char dis[20]={'0'};
void TIMER3B_IRQHandler(void)
{
    uint32_t getTimerIntStatus;

    /* Get the timer interrupt status and clear the same */
    getTimerIntStatus = MAP_TimerIntStatus(TIMER3_BASE, true);

    MAP_TimerIntClear(TIMER3_BASE, getTimerIntStatus);

    getTimerCaptureValue = MAP_TimerValueGet(TIMER3_BASE, TIMER_B);

    bSetEventFlag = 1;

    num[flag]=getTimerCaptureValue;
    flag++;

    //???????????,??2-4????

    if(flag==1)
    {
        MAP_TimerControlEvent(TIMER3_BASE, TIMER_B, TIMER_EVENT_POS_EDGE);
    }
    if(flag==2)
    {
        MAP_TimerControlEvent(TIMER3_BASE, TIMER_B, TIMER_EVENT_NEG_EDGE);
    }
    if(flag==3)
    {
        MAP_TimerControlEvent(TIMER3_BASE, TIMER_B, TIMER_EVENT_POS_EDGE);
    }
    if(flag==4)
    {
        MAP_TimerControlEvent(TIMER3_BASE, TIMER_B, TIMER_EVENT_NEG_EDGE);

        flag=0;

        Circle_low=num[2]-num[1];   //???????
        if(Circle_low<0)
            Circle_low=Circle_low+60000;

        Circle_high=num[3]-num[2];    //?????
        if(Circle_high<0)
            Circle_high=Circle_high+60000;

        total = Circle_high+ Circle_low;

        duty = Circle_high*1.0/total;
        frequency = 120000000/total;
          sprintf(output1,"duty=%f\r\n",duty);
				
      //   sprintf(dis,"frequancy=%dHz\r\n",frequency);
				UARTSend(( uint8_t *)output1,20); 
				delay_ms(1);
				//UARTSend(( uint8_t *)dis,20); 

        MAP_TimerDisable(TIMER3_BASE, TIMER_B);
    }
}















void capture_init()         // GPIO PA7-----  Timer-3 CCP1 pin           
{
     MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA)))
    {
    }

    /* Configure the GPIO PA7 as Timer-3 CCP1 pin */
    MAP_GPIOPinConfigure(GPIO_PA7_T3CCP1);
    MAP_GPIOPinTypeTimer(GPIO_PORTA_BASE, GPIO_PIN_7);

    /* Enable the Timer-3 in 16-bit Edge Time mode */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER3)))
    {
    }

    MAP_TimerConfigure(TIMER3_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_CAP_TIME_UP);

    MAP_TimerControlEvent(TIMER3_BASE, TIMER_B, TIMER_EVENT_NEG_EDGE);

    MAP_TimerLoadSet(TIMER3_BASE, TIMER_B, 120000000/2000);   //?????60000

    MAP_TimerConfigure(TIMER3_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_CAP_TIME_UP);

    MAP_TimerIntEnable(TIMER3_BASE, TIMER_CAPB_EVENT);

    MAP_TimerEnable(TIMER3_BASE, TIMER_B);

    /* Enable the timer interrupt */
    MAP_IntEnable(INT_TIMER3B);



}

void enable_cap()   //when we are using,put this function in while(1)
{
      MAP_TimerIntEnable(TIMER3_BASE, TIMER_CAPB_EVENT);
      MAP_TimerEnable(TIMER3_BASE, TIMER_B);
}


void Timer0AIntHandler(void)             //Timer 0 interrupt
{
    uint32_t ui32Status = TimerIntStatus(TIMER0_BASE, true);

    TimerIntClear(TIMER0_BASE, ui32Status);

}


void Timer1AIntHandler(void)
{
    // ?? Timer1A ?????
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
      GPIOPinWrite(GPIO_PORTF_BASE, LED3_PIN, ~GPIOPinRead(GPIO_PORTF_BASE, LED3_PIN));
    // ???????????
}

void TIM1_init()
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);

    // ??Timer0??????
    TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER1_BASE, TIMER_A, 120000000 / 2);

    TimerIntRegister(TIMER1_BASE, TIMER_A, Timer1AIntHandler);
    TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    // ??Timer0A?????


    // ??Timer0A
    TimerEnable(TIMER1_BASE, TIMER_A);
}


