#include "driverlib.h"
#include "stdint.h"
#include "stdbool.h"
//#define zhan 1.5
void TIM_PWMConfig(void);
void PWM_Intxx(void);
void SetPWMzhan(uint16_t chan1,uint16_t chan2);

void PWM_Int4Channel(void);

void SetPWMBI(uint16_t chan1,uint16_t chan2,uint16_t chan3,uint16_t chan4);
