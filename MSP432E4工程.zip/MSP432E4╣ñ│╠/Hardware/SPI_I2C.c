
/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/******************************************************************************
 * MSP432E4 Example Project for I2C-Master for Burst Write and Read using I2C
 * FIFO and DMA.
 *
 * Description: This application example configures the I2C module for master
 * mode operation with standard speed. The use of the example requires another
 * MSP-EXP432E401Y board to be running i2c_slavemode_masterfifo_transfer
 * application.
 * The master board sends a 32 bytes to the slave using the FIFO. The master
 * board addresses the byte offset it wants to read from the slave device to
 * which the slave sends the data back to the master. The master uses the FIFO
 * to receive the data from the Slave. The actual data transfer phase during
 * the Master-TX and Master-RX operation is handled by the DMA. The master
 * compares the data byte stream read from the slave. If there is an error in
 * transmission the LED D2 is switched ON.
 *
 *                MSP432E401Y                      MSP432E401Y
 *             ------------------               ------------------
 *         /|\|      MASTER      |             |      SLAVE       |
 *          | |                  |             |                  |
 *          --|RST            PG0|<->I2C1SCL<->|PG0               |
 *            |               PG1|<->I2C1SDA<->|PG1               |
 *            |                  |             |                  |
 *            |               PN0|-->LED D2    |                  |
 *            |                  |             |                  |
 *            |                  |             |                  |
 * Author: 
*******************************************************************************/
/* DriverLib Includes */
#include <driverlib.h>
#include "SPI_I2C.h"

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

/* Defines for I2C bus parameters */
#define SLAVE_ADDRESS   0x26
#define I2C_NUM_DATA    32

/* Enumerated Data Types for I2C State Machine */
enum I2C_MASTER_STATE
{
    I2C_OP_IDLE = 0,
    I2C_OP_FIFO,
    I2C_OP_TXDATA,
    I2C_OP_RXDATA,
    I2C_OP_STOP,
    I2C_ERR_STATE
};

/* Variables for I2C data and state machine */
volatile uint8_t  sendMasterTxData[I2C_NUM_DATA];
uint8_t           getMasterRxData[I2C_NUM_DATA];
volatile uint8_t  setMasterCurrState;
volatile uint8_t  setMasterPrevState;
volatile bool     setI2CDirection;
volatile uint8_t  setMasterBytes       = I2C_NUM_DATA;
const    uint8_t  setMasterBytesLength = I2C_NUM_DATA;
volatile uint8_t  setReadPointerStart;

void I2C1__IRQHandler(void)//��д�жϷ�����
{
    uint32_t getInterruptStatus;

    /* Get the masked interrupt status */
    getInterruptStatus = MAP_I2CMasterIntStatusEx(I2C1_BASE, true);

    /* Execute the State Machine */
    switch (setMasterCurrState) {
    case I2C_OP_IDLE://д��
        /* Move from IDLE to Transmit Address State */
        setMasterPrevState = setMasterCurrState;
        setMasterCurrState = I2C_OP_FIFO;

        /* Write the transfer length to the Slave during write. When reading
         * the data from the slave send the start address of the bytes to be
         * read back */
        MAP_I2CMasterSlaveAddrSet(I2C1_BASE, SLAVE_ADDRESS, false);
        if(!setI2CDirection)
        {
            MAP_I2CMasterDataPut(I2C1_BASE, (I2C_NUM_DATA-1));
        }
        else
        {
            MAP_I2CMasterDataPut(I2C1_BASE, setReadPointerStart);
        }
        MAP_I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_BURST_SEND_START);
        break;

    case I2C_OP_FIFO://д��
        /* If Last Data has been NAK'ed then go to stop state */
        if(getInterruptStatus & I2C_MASTER_INT_NACK)
        {
            setMasterCurrState = I2C_OP_STOP;
        }
        /* Based on the direction move to the appropriate state of Transmit or
         * Receive. Also send the BURST command for FIFO Operations. */
        else if(!setI2CDirection)
        {
            setMasterCurrState = I2C_OP_TXDATA;
            MAP_I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_FIFO_BURST_SEND_FINISH);
        }
        else
        {
            setMasterCurrState = I2C_OP_RXDATA;
            MAP_I2CMasterSlaveAddrSet(I2C1_BASE, SLAVE_ADDRESS, true);
            MAP_I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_FIFO_SINGLE_RECEIVE);
        }
        break;

    case I2C_OP_TXDATA:
        /* Move the current state to the previous state else continue with the
         * transmission till last byte */
        setMasterPrevState = setMasterCurrState;

        /* If Address or Data has been NAK'ed then go to stop state. If a Stop
         * condition is seen due to number of bytes getting done then move to
         * STOP state */
        if(getInterruptStatus & I2C_MASTER_INT_NACK)
        {
            setMasterCurrState = I2C_OP_STOP;
        }
        else if(getInterruptStatus & I2C_MASTER_INT_STOP)
        {
            setMasterCurrState = I2C_OP_STOP;
        }
        else if(getInterruptStatus & I2C_MASTER_INT_TX_DMA_DONE)
        {
            setMasterCurrState = I2C_OP_TXDATA;
        }
        else
        {
            setMasterCurrState = I2C_ERR_STATE;
        }
        break;

    case I2C_OP_RXDATA:
        /* Move the current state to the previous state else continue with the
         * transmission till last byte */
        setMasterPrevState = setMasterCurrState;

        /* If Address has been NAK'ed then go to stop state. If a Stop
         * condition is seen due to number of bytes getting done then move to
         * STOP state and read the last data byte */
        if(getInterruptStatus & I2C_MASTER_INT_NACK)
        {
            setMasterCurrState = I2C_OP_STOP;
        }
        else if(getInterruptStatus & I2C_MASTER_INT_STOP)
        {
            setMasterCurrState = I2C_OP_STOP;
        }
        else if(getInterruptStatus & I2C_MASTER_INT_RX_DMA_DONE)
        {
            setMasterCurrState = I2C_OP_RXDATA;
        }
        else
        {
            setMasterCurrState = I2C_ERR_STATE;
        }
        break;

    case I2C_OP_STOP:
        /* Move the current state to the previous state else continue with the
         * transmission till last byte */
        setMasterPrevState = setMasterCurrState;
        break;

    case I2C_ERR_STATE:
        setMasterCurrState = I2C_ERR_STATE;
        break;

    default:
        setMasterCurrState = I2C_ERR_STATE;
        break;
    }

    /* Clear the Interrupt Status flags */
    MAP_I2CMasterIntClearEx(I2C1_BASE, getInterruptStatus);
}

/* This function sets up UDMA Channel Control Structures for TX */
void
ConfigureuDMATX(uint8_t ui8Length, uint32_t ui32ArbSize)
{
    /* Put the attributes in a known state for the uDMA channel. These should
     *  already be disabled by default. */
    MAP_uDMAChannelAttributeDisable(UDMA_CH9_I2C1TX, UDMA_ATTR_USEBURST |
                                    UDMA_ATTR_ALTSELECT |
                                    UDMA_ATTR_HIGH_PRIORITY |
                                    UDMA_ATTR_REQMASK);

    /* Configure the control parameters for the I2C1 TX channel.  The channel
     * will be used to transfer between memory buffer and I2CFIFODATA register
     * 8 bits at a time. Therefore the data size is 8 bits, and the address
     * increment is 8 bits for source. The destination increment is none.
     * The arbitration size will be set based on the TX FIFO Threshold, which
     * causes the uDMA controller to rearbitrate after N items are
     * transferred. This keeps this channel from hogging the uDMA controller
     * once the transfer is started and allows other channels cycles if they
     * are higher priority. */
    MAP_uDMAChannelControlSet(UDMA_CH9_I2C1TX | UDMA_PRI_SELECT,
                              UDMA_SIZE_8 | UDMA_SRC_INC_8 | UDMA_DST_INC_NONE |
                              ui32ArbSize);

    /* Set up the transfer parameters for the hardware channel.  This will
     * configure the transfer buffers and the transfer size.  Basic mode
     * is used in this example */
    MAP_uDMAChannelTransferSet(UDMA_CH9_I2C1TX | UDMA_PRI_SELECT,
                               UDMA_MODE_BASIC, (void *)&sendMasterTxData,
                               (void *)&I2C1->FIFODATA, ui8Length);

    /* The channel must be enabled.  For hardware based transfers, a request
     * must be issued by the peripheral.  After this, the uDMA memory transfer
     * begins. */
    MAP_uDMAChannelEnable(UDMA_CH9_I2C1TX);

}

/* This function sets up UDMA Channel Control Structures for RX */
void
ConfigureuDMARX(uint8_t ui8Length, uint32_t ui32ArbSize)
{
    /* Put the attributes in a known state for the uDMA software channel.
     * These should already be disabled by default. */
    MAP_uDMAChannelAttributeDisable(UDMA_CH8_I2C1RX, UDMA_ATTR_USEBURST |
                                                     UDMA_ATTR_ALTSELECT |
                                                     UDMA_ATTR_HIGH_PRIORITY |
                                                     UDMA_ATTR_REQMASK);

    /* Configure the control parameters for the I2C1 RX channel.  The channel
     * will be used to transfer between I2CFIFODATA register and memory
     * buffers, 8 bits at a time. Therefore the data size is 8 bits, and the
     * address increment is 8 bits for destination. The source increment is
     * none. The arbitration size will be set based on the RX FIFO Threshold,
     * which causes the uDMA controller to rearbitrate after N items are
     * transferred.This keeps this channel from hogging the uDMA controller
     * once the transfer is started and allows other channels cycles if they
     * are higher priority. */
    MAP_uDMAChannelControlSet(UDMA_CH8_I2C1RX | UDMA_PRI_SELECT,
                          UDMA_SIZE_8 | UDMA_SRC_INC_NONE | UDMA_DST_INC_8 |
                          ui32ArbSize);

    /* Set up the transfer parameters for the hardware channel.  This will
     * configure the transfer buffers and the transfer size.  Basic mode
     * is used in this example */
    MAP_uDMAChannelTransferSet(UDMA_CH8_I2C1RX | UDMA_PRI_SELECT,
                           UDMA_MODE_BASIC, (void *)&I2C1->FIFODATA,
                           (void *)&getMasterRxData, ui8Length);

    /* The channel must be enabled.  For hardware based transfers, a request
     * must be issued by the peripheral.  After this, the uDMA memory transfer
     * begins. */
    MAP_uDMAChannelEnable(UDMA_CH8_I2C1RX);

}

void I2C_RxTx(void)
{
    uint8_t  ii;
    uint8_t  setTemp;
    uint32_t systemClock;
    uint32_t setTxArbSize, setRxArbSize;

    /* Configure the system clock for 120 MHz */
    systemClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                          SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                                          120000000);

    /* Enable clocks to GPIO Port N and configure pins as Output */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    while(!(MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPION)))
    {
    }
    MAP_GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
    MAP_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0);

    /* Enable the DMA and Configure Channel for I2C1 TX and RX for Basic mode
     * of transfer */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UDMA);
    while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_UDMA)))
    {
    }

    MAP_uDMAEnable();

    /* Point at the control table to use for channel control structures. */
    MAP_uDMAControlBaseSet(pui8_ControlTable);

    /* Assign the UDMA Channel for I2C1 RX and TX DMA Request */
    MAP_uDMAChannelAssign(UDMA_CH8_I2C1RX);
    MAP_uDMAChannelAssign(UDMA_CH9_I2C1TX);

    /* Enable clocks to GPIO Port G and configure pins as I2C */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
    while(!(MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOG)))
    {
    }

    MAP_GPIOPinConfigure(GPIO_PG0_I2C1SCL);
    MAP_GPIOPinConfigure(GPIO_PG1_I2C1SDA);
    MAP_GPIOPinTypeI2C(GPIO_PORTG_BASE, GPIO_PIN_1);
    MAP_GPIOPinTypeI2CSCL(GPIO_PORTG_BASE, GPIO_PIN_0);

    /* Since there are no board pull up's we shall enable the weak internal
     * pull up ���������������δ����*/
    GPIOG->PUR |= (GPIO_PIN_1 | GPIO_PIN_0);

    /* Enable the clock to I2C-1 module and configure the I2C Master */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C1);
    while(!(MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_I2C1)))
    {
    }

    /* Configure the I2C Master in standard mode and enable interrupt for
     * Arbitration Lost, Stop, NAK, Timeout and Data completion condition
     * on the bus */
    MAP_I2CMasterInitExpClk(I2C1_BASE, systemClock, true);//��Ϊtrue����ģʽ
    MAP_I2CMasterIntEnableEx(I2C1_BASE, (I2C_MASTER_INT_ARB_LOST |
                                         I2C_MASTER_INT_STOP |
                                         I2C_MASTER_INT_NACK |
                                         I2C_MASTER_INT_TIMEOUT |
                                         I2C_MASTER_INT_DATA));

    /* Assign the Transmit and Receive FIFO to the Master Transmit threshold
     * of 2 means that when there are less than or equal to 2 bytes in the TX
     * FIFO then generate an interrupt.
     * Receive threshold of 6 means that when there are more than or equal to
     * 6 bytes in the RX FIFO then generate an interrupt. */
    MAP_I2CTxFIFOConfigSet(I2C1_BASE, I2C_FIFO_CFG_TX_MASTER_DMA |
                                      I2C_FIFO_CFG_TX_TRIG_2);
    MAP_I2CRxFIFOConfigSet(I2C1_BASE, I2C_FIFO_CFG_RX_MASTER_DMA |
                                      I2C_FIFO_CFG_RX_TRIG_3);

    /* Transmit uDMA Arbitrartion size is calculated as the
     * smaller mod 2 which can write to the TXFIFO without
     * overrun
     * TX TRIGGER               ARB
     * I2C_FIFO_CFG_TX_NO_TRIG  UDMA_ARB_8
     * I2C_FIFO_CFG_TX_TRIG_1   UDMA_ARB_4
     * I2C_FIFO_CFG_TX_TRIG_2   UDMA_ARB_4
     * I2C_FIFO_CFG_TX_TRIG_3   UDMA_ARB_4
     * I2C_FIFO_CFG_TX_TRIG_4   UDMA_ARB_4
     * I2C_FIFO_CFG_TX_TRIG_5   UDMA_ARB_2
     * I2C_FIFO_CFG_TX_TRIG_6   UDMA_ARB_2
     * I2C_FIFO_CFG_TX_TRIG_7   UDMA_ARB_1 */
    setTxArbSize = UDMA_ARB_4;

    /* Flush any existing data in the FIFO */
    MAP_I2CTxFIFOFlush(I2C1_BASE);
    MAP_I2CRxFIFOFlush(I2C1_BASE);

    /* Enable the Glitch Filter */
    MAP_I2CMasterGlitchFilterConfigSet(I2C1_BASE, I2C_MASTER_GLITCH_FILTER_8);

    /* Enable the interrupt generation from I2C-1 */
    MAP_IntEnable(INT_I2C1);

    /* Initialize the Master Transmit Buffer with Random Data and clear the
     * Master Receive Buffer */
    for(ii = 0; ii < I2C_NUM_DATA; ii++)
    {
        sendMasterTxData[ii] = rand() & 0xFF;//rand()�����������
        getMasterRxData[ii]  = 0x0;
    }


    /* Initialize the state of the I2C Master */
    setMasterCurrState = I2C_OP_IDLE;//д��
    MAP_I2CMasterBurstLengthSet(I2C1_BASE, setMasterBytesLength);

    /* Set Transmit Flag */
    setI2CDirection     = false;//����
    setMasterBytes      = 0;

    /* When sending data to slave make sure RX DMA DONE interrupt bit is
     * masked and TX DMA DONE interrupt bit is unmasked. */
		//���������������ʱ��ȷ��RX DMA DONE�ж�λ�����Σ�TX DMA DONE�ж�λ��ȡ�����Ρ�
    MAP_I2CMasterIntEnableEx(I2C1_BASE, I2C_MASTER_INT_TX_DMA_DONE);//ʹ��TX DMA DONE�ж�
    MAP_I2CMasterIntDisableEx(I2C1_BASE, I2C_MASTER_INT_RX_DMA_DONE);//����RX DMA DONE�ж�

    /* Configure the uDMA Control Channel Structure for TX */
    ConfigureuDMATX(setMasterBytesLength, setTxArbSize);

    /* Trigger the Transfer using Software Interrupt */
    MAP_IntTrigger(INT_I2C1);
    while(setMasterCurrState != I2C_OP_STOP);

    /* When receiving data from slave make sure TX DMA DONE interrupt bit is
     * masked and RX DMA DONE interrupt bit is unmasked */
    MAP_I2CMasterIntEnableEx(I2C1_BASE, I2C_MASTER_INT_RX_DMA_DONE);
    MAP_I2CMasterIntDisableEx(I2C1_BASE, I2C_MASTER_INT_TX_DMA_DONE);

    /* Receive uDMA Arbitrartion size is calculated as the
     * Trigger Level to read back data from RXFIFO without
     * an underrun
     * RX TRIGGER               ARB
     * I2C_FIFO_CFG_RX_NO_TRIG  INVALID
     * I2C_FIFO_CFG_RX_TRIG_1   UDMA_ARB_1
     * I2C_FIFO_CFG_RX_TRIG_2   UDMA_ARB_2
     * I2C_FIFO_CFG_RX_TRIG_3   UDMA_ARB_2
     * I2C_FIFO_CFG_RX_TRIG_4   UDMA_ARB_4
     * I2C_FIFO_CFG_RX_TRIG_5   UDMA_ARB_4
     * I2C_FIFO_CFG_RX_TRIG_6   UDMA_ARB_4
     * I2C_FIFO_CFG_RX_TRIG_7   UDMA_ARB_4 */
    setRxArbSize = UDMA_ARB_2;

    /* Configure the uDMA Control Channel Structure for RX */
    ConfigureuDMARX(setMasterBytesLength,setRxArbSize);

    /* Set the I2CMBLEN register and also initialize */
    MAP_I2CMasterBurstLengthSet(I2C1_BASE, setMasterBytesLength);

    /* Set receive Flag with Repeated Start. Also Receive Buffer is calculated
     *  as the Trigger Level to read back data. */
    setI2CDirection        = true;
    setMasterBytes         = 0;
    setReadPointerStart    = 4;
    setMasterCurrState     = I2C_OP_IDLE;

    /* Trigger the Transfer using Software Interrupt */
    MAP_IntTrigger(INT_I2C1);
    while(setMasterCurrState != I2C_OP_STOP);
    setMasterCurrState = I2C_OP_IDLE;

    /* Perform Data Integrity Check here */
    setTemp = (I2C_NUM_DATA - 1) - setReadPointerStart;

    for(ii = 0; ii < I2C_NUM_DATA; ii++)
    {
        /* Adjust the temp pointer to the read buffer to implement a circular
         * read buffer */
        if(setTemp == (I2C_NUM_DATA-1))
        {
            setTemp = 0;
        }
        else
        {
            setTemp++;
        }

        if(sendMasterTxData[ii] != getMasterRxData[setTemp])
        {
            MAP_GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, GPIO_PIN_0);
        }
    }

    while(1);
}





