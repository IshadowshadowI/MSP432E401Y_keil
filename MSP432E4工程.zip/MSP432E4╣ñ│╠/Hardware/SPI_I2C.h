#include "driverlib.h"
/* Defines for I2C bus parameters */
#define SLAVE_ADDRESS   0x26
#define I2C_NUM_DATA    32


void I2C_RxTx(void);
void I2C1__IRQHandler(void);
void ConfigureuDMATX(uint8_t ui8Length, uint32_t ui32ArbSize);
void ConfigureuDMARX(uint8_t ui8Length, uint32_t ui32ArbSize);

/* The control table used by the uDMA controller.  This table must be aligned
 * to a 1024 byte boundary. */
#if defined(__ICCARM__)
#pragma data_alignment=1024
uint8_t pui_8ControlTable[1024];
#elif defined(__TI_ARM__)
#pragma DATA_ALIGN(pui8ControlTable, 1024)
uint8_t pui8_ControlTable[1024];
#else
uint8_t pui8_ControlTable[1024] __attribute__ ((aligned(1024)));
#endif


