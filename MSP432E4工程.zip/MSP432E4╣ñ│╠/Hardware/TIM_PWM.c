#include "TIM_PWM.h"
#include "stdint.h"
#include "stdbool.h"


#define zhan 40000/65536

void TIM_PWMConfig(void)
{
    uint32_t systemClock;

    /* ����ϵͳʱ��Ϊ 120 MHz */
    systemClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                          SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                                          120000000);

    /* ʹ��GPIO Port A ��ʱ�Ӳ��ȴ���� */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA)))
    {
    }

    /* ���� GPIO PA4 --->Timer-2 CCP0 ��� 
						GPIO PA5 --->Timer-2 CCP1
						GPIO PA6 --->Timer-3 CCP0
						GPIO PA7 --->Timer-3 CCP1 */
    MAP_GPIOPinConfigure(GPIO_PA4_T2CCP0);//�ú���ֻ����Ψһ����
		MAP_GPIOPinConfigure(GPIO_PA5_T2CCP1);
		MAP_GPIOPinConfigure(GPIO_PA6_T3CCP0);
//		MAP_GPIOPinConfigure(GPIO_PA7_T3CCP1);
		
    MAP_GPIOPinTypeTimer(GPIO_PORTA_BASE,GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6/* | GPIO_PIN_7*/);


    /* ʹ��Timer-3/2 Ϊ16λ PWM ģʽ 
																			���ȴ����*/
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);
		while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER2)))
    {
    }
		MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    while(!(SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER3)))
    {
    }

    MAP_TimerConfigure(TIMER3_BASE, TIMER_CFG_PERIODIC );/*�ú�������A\B��Ҫͬʱ���ã�
																																	��TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_PWM | TIMER_CFG_A_PWM��ʽ*/
		MAP_TimerConfigure(TIMER2_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_B_PWM | TIMER_CFG_A_PWM);

 
     /*��Timer3B����ֵ����ΪsystemClock / 2000���Ի��2KHzPWM���������ֵ=ʱ��Ƶ��f/pwmƵ��F��
		  *Ҫ���66����ռ�ձȣ���ƥ��ֵ����Ϊװ��ֵ��1/3
		  *��ʱ��Ӧ�Ӹ���ֵ������ƥ��ֵ����ߵ�ƽ��
		  *��ƥ��ֵ��0����ʱ���ǵ͵�ƽ������ʱ�����¼����� */
    MAP_TimerLoadSet(TIMER3_BASE, TIMER_A, systemClock/2000);
		MAP_TimerLoadSet(TIMER2_BASE, TIMER_BOTH, systemClock/2000);

//    MAP_TimerMatchSet(TIMER3_BASE, TIMER_B ,
//                  MAP_TimerLoadGet(TIMER3_BASE,  TIMER_B ) / 3);
		
		MAP_TimerMatchSet(TIMER3_BASE, TIMER_A ,
                  MAP_TimerLoadGet(TIMER3_BASE,  TIMER_A ) / 3);

    MAP_TimerMatchSet(TIMER2_BASE, TIMER_B ,
                  MAP_TimerLoadGet(TIMER2_BASE,  TIMER_B ) / 3);
		MAP_TimerMatchSet(TIMER2_BASE, TIMER_A ,
                  MAP_TimerLoadGet(TIMER2_BASE,  TIMER_A ) / 3);

    /* Enable the timer count ��ʹ�ܶ�ʱ����*/
    MAP_TimerEnable(TIMER3_BASE,  TIMER_A);
		MAP_TimerEnable(TIMER2_BASE,  TIMER_BOTH);

}


void PWM_Intxx(void)
{
	volatile uint16_t setDelay;

    /* Configure the system clock for 120MHz internal oscillator */
		MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                          SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                                          120000000);

    /* The PWM peripheral must be enabled for use. */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    while(!(MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0)));

    /* Set the PWM clock to the system clock. */
    MAP_PWMClockSet(PWM0_BASE,PWM_SYSCLK_DIV_8);//��ϵͳʱ��8��Ƶ��ΪPWMʱ��

    /* Enable the clock to the GPIO Port F, G and K for PWM pins */

    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOG));
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOK));


    /* Generator 2 Pins */
    MAP_GPIOPinConfigure(GPIO_PG0_M0PWM4);
    MAP_GPIOPinConfigure(GPIO_PG1_M0PWM5);

    /* Generator 3 Pins */
    MAP_GPIOPinConfigure(GPIO_PK4_M0PWM6);
    MAP_GPIOPinConfigure(GPIO_PK5_M0PWM7);


    MAP_GPIOPinTypePWM(GPIO_PORTG_BASE, (GPIO_PIN_0 | GPIO_PIN_1));
    MAP_GPIOPinTypePWM(GPIO_PORTK_BASE, (GPIO_PIN_4 | GPIO_PIN_5));



    MAP_PWMGenConfigure(PWM0_BASE, PWM_GEN_2, PWM_GEN_MODE_UP_DOWN |
                        PWM_GEN_MODE_DB_SYNC_LOCAL);
    MAP_PWMGenConfigure(PWM0_BASE, PWM_GEN_3, PWM_GEN_MODE_UP_DOWN |
                        PWM_GEN_MODE_DB_SYNC_LOCAL);

    /* Set the PWM period to 250Hz.  To calculate the appropriate parameter
     * use the following equation: N = (1 / f) * SysClk.  Where N is the
     * function parameter, f is the desired frequency, and SysClk is the
     * system clock frequency.
     * In this case you get: (1 / 250Hz) * 15MHz = 60000 cycles.  Note that
     * the maximum period you can set is 2^16 - 1.
     * TODO: modify this calculation to use the clock frequency that you are
     * using. */

    MAP_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_2, 60000);
    MAP_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, 60000);

    /* PWMs           Positive Duty Cycle
     * Bit 1 (PF1)    25%
     * Bit 2 (PF2)    50%
     * Bit 3 (PF3)    75%
     * Bit 4 (PG0)    25%
     * Bit 5 (PG1)    75% (dead band from Bit4)
     * Bit 6 (PK4)    75%
     * Bit 7 (PK5)    25% (dead band from Bit6) */

    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_2) / 2);
    MAP_PWMDeadBandEnable(PWM0_BASE, PWM_GEN_2, 160, 160);

    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_3) / 2);
    MAP_PWMDeadBandEnable(PWM0_BASE, PWM_GEN_3, 160, 160);

    /* Enable the PWM0 output signals
     *   Bit 1 (PF1) Bit 2 (PF2) and Bit 3 (PF3)
     *   Bit 4 (PG0) and Bit 5 (PG1)
     *   Bit 6 (PK4) and Bit 7 (PK5) */
    MAP_PWMOutputState(PWM0_BASE, (
                                     PWM_OUT_4_BIT | PWM_OUT_5_BIT |
                                     PWM_OUT_6_BIT | PWM_OUT_7_BIT ) , true);

    MAP_PWMOutputInvert(PWM0_BASE, (PWM_OUT_6_BIT | PWM_OUT_7_BIT) , true);

    /* Enables the counter for a PWM generator block. */
    MAP_PWMGenEnable(PWM0_BASE, PWM_GEN_2);

    for(setDelay = 0; setDelay < 10000; setDelay++);
		
    MAP_PWMGenEnable(PWM0_BASE, PWM_GEN_3);

    MAP_PWMSyncTimeBase(PWM0_BASE, (PWM_GEN_2_BIT | PWM_GEN_3_BIT));

    /* Loop forever while the PWM signals are generated. */
}
/*
����PWM��ռ�ձȣ����ô˺���ǰӦ�ȵ���PWM_Intxx(void)����
������Χ1--65535
*/

void SetPWMzhan(uint16_t chan1,uint16_t chan2)
{
	MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_3) / chan1);
	MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_3) / chan2);
	
}


void PWM_Int4Channel(void)
{
	    /* The PWM peripheral must be enabled for use. */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    while(!(MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0)));

    /* Set the PWM clock to the system clock. */
    MAP_PWMClockSet(PWM0_BASE,PWM_SYSCLK_DIV_8);
	    /* Enable the clock to the GPIO Port F,for PWM pins */
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));
		MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
    while(!MAP_SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOG));
    /* Generator 0 Pins */
    MAP_GPIOPinConfigure(GPIO_PF1_M0PWM1);

    /* Generator 1 Pins */
    MAP_GPIOPinConfigure(GPIO_PF2_M0PWM2);
    MAP_GPIOPinConfigure(GPIO_PF3_M0PWM3);
	
		/* Generator 2 Pins */
    MAP_GPIOPinConfigure(GPIO_PG0_M0PWM4);
	
		MAP_GPIOPinTypePWM(GPIO_PORTF_BASE, (GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3));
		MAP_GPIOPinTypePWM(GPIO_PORTG_BASE,  GPIO_PIN_0);
		
	    /* Configure the PWM0 to count up/down without synchronization.
     * Note: Enabling the dead-band generator automatically couples the 2
     * outputs from the PWM block so we don't use the PWM synchronization. */
    MAP_PWMGenConfigure(PWM0_BASE, PWM_GEN_0, PWM_GEN_MODE_UP_DOWN |
                        PWM_GEN_MODE_GEN_SYNC_LOCAL);
		MAP_PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_UP_DOWN |
                        PWM_GEN_MODE_GEN_SYNC_LOCAL);
		MAP_PWMGenConfigure(PWM0_BASE, PWM_GEN_2, PWM_GEN_MODE_UP_DOWN |
                        PWM_GEN_MODE_DB_SYNC_LOCAL);		 
		 /* Set the PWM period to 250Hz.  To calculate the appropriate parameter
     * use the following equation: N = (1 / f) * SysClk.  Where N is the
     * function parameter, f is the desired frequency, and SysClk is the
     * system clock frequency.
     * In this case you get: (1 / 500Hz) * 8MHz = 30000 cycles.  Note that
     * the maximum period you can set is 2^16 - 1.
     * TODO: modify this calculation to use the clock frequency that you are
     * using. */
    MAP_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, 30000);//��ʱ�ӵ���Ƶ�ʣ���ǰ��ķ�Ƶϵ���ɵ���pwmʱ��Ƶ��
		MAP_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, 30000);
		MAP_PWMGenPeriodSet(PWM0_BASE, PWM_GEN_2, 30000);
		//ռ�ձȵ���
		MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0) / 2);
    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_1) / 2);
    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_3,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_1) / 2);
		MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_2) / 2);
		    /* Enable the PWM0 output signals
         * Bit 1 (PF1) Bit 2 (PF2) and Bit 3 (PF3)
         */
    MAP_PWMOutputState(PWM0_BASE, (  PWM_OUT_1_BIT | PWM_OUT_2_BIT |
                                     PWM_OUT_3_BIT | PWM_OUT_4_BIT ) , true);
		/*ʹ��pwm*/
		MAP_PWMGenEnable(PWM0_BASE, PWM_GEN_0);
    MAP_PWMGenEnable(PWM0_BASE, PWM_GEN_1);
		MAP_PWMGenEnable(PWM0_BASE, PWM_GEN_2);
		
		MAP_PWMSyncTimeBase(PWM0_BASE, (PWM_GEN_0_BIT | PWM_GEN_1_BIT | PWM_GEN_2_BIT));//ͬ��ʱ��
		
		
}




void SetPWMBI(uint16_t chan1,uint16_t chan2,uint16_t chan3,uint16_t chan4)//1-65536��Ӧռ�ձȴ�0-100%
{
		MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_0) * chan1/65536);
    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_1) * chan2/65536);
    MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_3,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_1) * chan3/65536);
		MAP_PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4,
                     MAP_PWMGenPeriodGet(PWM0_BASE, PWM_GEN_2) * chan4/65536);
	  
}







